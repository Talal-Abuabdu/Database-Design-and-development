from django.contrib import admin
from .models import *


@admin.register(Patient)
class AdminPatient(admin.ModelAdmin):
    list_display = ('patient_id', 'patient_name', 'patient_number')


@admin.register(Doctor)
class AdminDoctor(admin.ModelAdmin):
    list_display = ('doctor_id', 'doctor_name')


@admin.register(Prescription)
class AdminPrescription(admin.ModelAdmin):
    list_display = ('patient', 'doctor')


@admin.register(Profile)
class AdminProfile(admin.ModelAdmin):
    list_display = ('pk', 'user_type')
