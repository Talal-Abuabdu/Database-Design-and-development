from django import forms
from .models import *


class AppointmentForm(forms.ModelForm):
    ''' Appointment Forms '''
    class Meta:
        model = Appointment
        exclude = ('appointment_status', )
        widgets = {
            'patient': forms.Select(attrs={'class': 'form-control'}),
            'doctor': forms.Select(attrs={'class': 'form-control'}),
            'appointment_date': forms.TextInput(attrs={
                'class': 'form-control', 'type': 'date'
            }),
            'appointment_time': forms.TextInput(attrs={
                'class': 'form-control', 'type': 'time'
            }),
        }

