from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

USER_TYPE = (
    (1, 'Doctor'),
    (2, 'Patient'),
)


class Patient(models.Model):
    patient_id = models.AutoField(primary_key=True)
    patient_name = models.CharField(max_length=100)
    patient_address = models.CharField(max_length=100)
    patient_number = models.CharField(max_length=100)
    class Meta:
        db_table = 'patients'
    

    def __str__(self):
        return self.patient_name


class Doctor(models.Model):
    doctor_id = models.AutoField(primary_key=True)
    doctor_name = models.CharField(max_length=100)
    doctor_address = models.CharField(max_length=100)
    doctor_number = models.CharField(max_length=100)

    class Meta:
        db_table = 'doctors'


    def __str__(self):
        return self.doctor_name

class Appointment(models.Model):
    appointment_id = models.AutoField(primary_key=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    appointment_date = models.DateField()
    appointment_time = models.TimeField()

    class Meta:
        db_table = 'appointments'


    def __str__(self):
        return f"Appointment ID: {self.id}"

class Prescription(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    prescription_date = models.DateField()
    medication_name = models.CharField(max_length=100)
    dosage = models.CharField(max_length=100)
    frequency = models.CharField(max_length=100)

    def __str__(self):
        return f"Prescription ID: {self.id}"


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True, unique=True)
    user_type = models.PositiveIntegerField(choices=USER_TYPE, default=1)


@receiver(post_save, sender=User)
def create_or_update_profile(sender, instance, created, **kwargs):
    """Creates or updates profile, when User object changes"""
    if created:
        Profile.objects.get_or_create(user=instance)
