from django.db.models import Q
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from .models import Appointment, Patient, Doctor, Prescription, Profile
from django.contrib.auth.forms import UserCreationForm
from .forms import AppointmentForm


@login_required
def main_menu(request):
    appointment = Appointment.objects.all().count()
    patient = Patient.objects.all().count()
    doctor = Doctor.objects.all().count()
    prescription = Prescription.objects.all().count()
    context = {
        'appointment': appointment, 'prescription': prescription,
        'patient': patient,
        'doctor': doctor
    }
    return render(request, 'index.html', context)


@login_required
def appointment_schedule(request):
    appointment = Appointment.objects.all().count()
    context = {
        'appointment': appointment
    }
    if request.method == 'POST':
        appointment_addition(request)
    return render(request, 'appointment_schedule.html', context)


@login_required
def appointment_addition(request):
    form = AppointmentForm()
    context = {
        'form': form
    }
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('appointment_schedule')
        else:
            context = {
                'form': form
            }
            return render(request, 'appointment_addition.html', context)
    return render(request, 'appointment_addition.html', context)


@login_required
def appointment_update(request, appointment_id):
    appointment = Appointment.objects.get(appointment_id=appointment_id)
    form = AppointmentForm(instance=appointment)
    context = {
        'form': form
    }
    if request.method == 'POST':
        form = AppointmentForm(request.POST, instance=appointment)
        if form.is_valid():
            form.save()
            return redirect('appointment_schedule')
        else:
            context = {
                'form': form
            }
            return render(request, 'appointment_addition.html', context)
    return render(request, 'appointment_addition.html', context)


@login_required
def appointment_delete(request, appointment_id):
    try:
        appointment = Appointment.objects.get(appointment_id=appointment_id)
        appointment.delete()
        return redirect('appointment_schedule')
    except Exception as e:
        print(e)
        return render(request, 'appointment_addition.html')


@login_required
def appointment_delete(request, appointment_id):
    appointment = Appointment.objects.get(pk=appointment_id)
    appointment.delete()
    return redirect('appointment_list')


@login_required
def appointment_list(request):
    appointments = Appointment.objects.all()
    search = request.GET.get('q')
    if search:
        search = search.strip()
        appointments = appointments.filter(
            Q(patient__patient_name__icontains=search) | Q(doctor__doctor_name__icontains=search)
        )
    context = {
        'appointments': appointments,
        'search': search
    }
    return render(request, 'appointment_list.html', context)


@login_required
def patient_record(request):
    patients = Patient.objects.all()
    search = request.GET.get('q')
    if search:
        search = search.strip()
        patients = patients.filter(
            Q(patient_name__icontains=search) | Q (patient_address__icontains=search)
            | Q(patient_number__icontains=search)
        )
    context = {'patients': patients, 'search': search}
    return render(request, 'patient_record.html', context)


@login_required
def doctor_record(request):
    doctors = Doctor.objects.all()
    search = request.GET.get('q')
    if search:
        search = search.strip()
        doctors = doctors.filter(
            Q(doctor_name__icontains=search) | Q (doctor_address__icontains=search)
            | Q(doctor_number__icontains=search)
        )
    context = {'doctors': doctors, 'search': search}
    return render(request, 'doctor_record.html', context)


@login_required
def prescription_history(request):
    prescriptions = Prescription.objects.all()
    if request.method == 'POST':
        patient_id = request.POST['patient_id']
        try:
            prescriptions = prescriptions.filter(patient_id=patient_id)
        except Prescription.DoesNotExist:            prescriptions = None

        context = {'prescriptions': prescriptions}
        return render(request, 'prescription_history.html', context)
    else:
        context = {'prescriptions': prescriptions}
        return render(request, 'prescription_history.html', context)


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username , password=password)
        if user is not None:
            login(request, user)
            return redirect('main_menu')
        else:
            return render(request, '_login.html', {'error': 'Invalid credentials'})

    return render(request, '_login.html')


def register(request):
    if request.method == 'POST':
        user_type = request.POST.get('user_type')
        form = UserCreationForm(request.POST)
        if form.is_valid():
            obj = form.save()
            profile = Profile.objects.get(pk=obj.profile.pk)
            profile.user_type = user_type
            profile.save()
            return redirect('login')  # Redirect to the login page
    else:
        form = UserCreationForm()
    return render(request, '_register.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')

