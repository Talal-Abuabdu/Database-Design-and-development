import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class NetworkEquipment {
    private String name;
    private String manufacturer;
    private String modelNumber;
    private String serialNumber;
    private String macAddress;
    private String ipAddress;
    private String location;
    private LinkedList<NetworkEquipment> connections;

    public NetworkEquipment(String name, String manufacturer, String modelNumber, String serialNumber,
                            String macAddress, String ipAddress,
                            String location) {
        this.name = name;
        this.manufacturer = manufacturer;
        this.modelNumber = modelNumber;
        this.serialNumber = serialNumber;
        this.macAddress = macAddress;
        this.ipAddress = ipAddress;
        this.location = location;
        this.connections = new LinkedList<>();
    }

    // Getters and setters

    public String getSerialNumber() {
        return serialNumber;
    }
    public String getIpAddress() {
        return ipAddress;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void connect(NetworkEquipment equipment) {
        connections.add(equipment);
    }

    public void disconnect(NetworkEquipment equipment) {
        connections.remove(equipment);
    }
    @Override
    public String toString() {
        return
                "name='" + name + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", modelNumber='" + modelNumber + '\'' +
                ", serialNumber='" + serialNumber + '\'' +
                ", macAddress='" + macAddress + '\'' +
                ", currentIpAddress='" + ipAddress + '\'' +
                ", currentLocation='" + location + '\'' +
                '}';
    }
}