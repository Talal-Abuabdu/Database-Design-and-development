import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;

public class Library {
    private static LinkedList<NetworkEquipment> equipmentList = new LinkedList<>();
    private static LinkedList<NetworkEquipment> updatedEquipmentList = new LinkedList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = false;
        loadData("Equipment.txt");
        while (!running) {
            // Display menu options
            System.out.println("------ Network Equipment Library ------");
            System.out.println("1. Add new equipment");
            System.out.println("2. Find equipment by Serial number");
            System.out.println("3. Find equipment by IP Address");
            System.out.println("4. Update equipment location");
            System.out.println("5. Get all the equipment");
            System.out.println("6. Connect equipment to another equipment");
            System.out.println("7. Disconnect equipment from another equipment");
            System.out.println("8. Get last updated equipment");
            System.out.println("9. Get all equipment in a location");
            System.out.println("10. Get last N updated equipment");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            // Get user's choice
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addNewEquipment();
                    break;
                case 2:
                    findEquipmentBySerialNumber();
                    break;
                case 3:
                    findEquipmentByIpAddress();
                    break;
                case 4:
                    updateEquipmentLocation();
                    break;
                case 5:
                    getAllEquipment();
                    break;
                case 6:
                    connectTwoEquipment();
                    break;
                case 7:
                    disconnectEquipment();
                    break;
                case 8:
                    getLastUpdatedEquipment();
                    break;
                case 9:
                    getAllCurrentEquipmentInLocation();
                    break;
                case 10:
                    getLastNUpdatedEquipment();
                    break;
                case 0:
                    running = true;
                    System.out.println("Exited Network Equipment Library");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            }
        }
    }

    // Add new equipment to the library
    private static void addNewEquipment() {
        try {
            System.out.println("Enter equipment details:");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Manufacturer: ");
            String manufacturer = scanner.nextLine();
            System.out.print("Model number: ");
            String modelNumber = scanner.nextLine();
            System.out.print("Serial number: ");
            String serialNumber = scanner.nextLine();
            System.out.print("MAC address: ");
            String macAddress = scanner.nextLine();

            String ipAddress = null;
            while (ipAddress == null) {
                System.out.print("IP address: ");
                String input = scanner.nextLine();
                if (input.matches("\\d+(\\.\\d+){3}")) {
                    // if input matches IPV4 address format, assign it to ipAddress
                    ipAddress = input;
                } else {
                    System.out.println("Invalid IP address format. Please enter a valid IP address.");
                }
            }

            String location = null;
            while (location == null) {
                System.out.print("Location: ");
                String input = scanner.nextLine();
                if (!input.isEmpty()) {
                    // If input is not empty, assign it to location
                    location = input;
                } else {
                    System.out.println("Location cannot be empty. Please enter a valid location.");
                }
            }

            // Create a new NetworkEquipment and add it to the equipment list
            NetworkEquipment equipment = new NetworkEquipment(name, manufacturer, modelNumber, serialNumber, macAddress,
                    ipAddress, location);
            equipmentList.add(equipment);
            System.out.println("Equipment added successfully.");
            fileSaver();
        } catch (Exception e) {
            System.out.println("An error occurred while adding new equipment: " + e.getMessage());
        }
    }



    // Find equipment by its serial number
    private static void findEquipmentBySerialNumber() {
        try {
            System.out.print("Enter the Serial Number of the equipment you want to find: ");
            String serialNumSearch = scanner.nextLine();

            // Search the equipmentList for the specified serial number
            for (NetworkEquipment equipment : equipmentList) {
                if (equipment.getSerialNumber().equals(serialNumSearch)) {
                    System.out.println("Equipment Found:");
                    System.out.println(equipment.toString());
                    return;
                }
            }

            System.out.println("Equipment not found.");
        } catch (Exception e) {
            System.out.println("An error occurred while searching for equipment: " + e.getMessage());
        }
    }


    // Find equipment by its IP address
    private static void findEquipmentByIpAddress() {
        // try & catch to implement error handling
        try {
            System.out.print("Enter the IP Address of the equipment you want to find: ");
            String ipAddressSearch = scanner.nextLine();

            // Validate that the IP address is enetered in IPV4 format
            if (!ipAddressSearch.matches("\\d+(\\.\\d+){3}")) {
                System.out.println("Invalid IP, make sure you enter IPV4 in the format Y.Y.Y.Y where Y " +
                        "can be any number from 0-225");
                return;
            }

            // Search the equipmentList for the specified IP address
            for (NetworkEquipment equipment : equipmentList) {
                if (equipment.getIpAddress().equals(ipAddressSearch)) {
                    System.out.println("Equipment Found:");
                    System.out.println(equipment.toString());
                    return;
                }
            }

            System.out.println("Equipment not found.");
        } catch (Exception e) {
            System.out.println("An error occurred while searching for equipment: " + e.getMessage());
        }
    }


    // Update the location of an equipment
    private static void updateEquipmentLocation() {
        System.out.print("Enter the serial number of the equipment you want to update: ");
        String updateSerialNum = scanner.nextLine();
        System.out.print("Enter the updated Location: ");
        String updatedLocation = scanner.nextLine();

        // Check if input is empty or null
        if (updateSerialNum.isEmpty() || updatedLocation.isEmpty()) {
            System.out.println("Please give a serial number and a location.");
            return;
        }

        // Search the equipmentList for the specified serial number and update its location
        for (NetworkEquipment equipment : equipmentList) {
            if (equipment.getSerialNumber().equals(updateSerialNum)) {
                // Update the location
                equipment.setLocation(updatedLocation);
                // Add the updated equipment to the updatedEquipmentList
                updatedEquipmentList.add(equipment);
                fileSaver();
                System.out.println("Location has been updated.");
                return;
            }
        }

        System.out.println("Equipment not found.");
    }


    // Connect two equipment together
    private static void connectTwoEquipment() {
        System.out.print("Enter the serial number of the first equipment: ");
        String serialNum1 = scanner.nextLine();
        System.out.print("Enter the serial number of the second equipment: ");
        String serialNum2 = scanner.nextLine();

        // Find the two equipment objects based on the provided serial number inputs
        NetworkEquipment equipment1 = findEquipmentBySerialNumber(serialNum1);
        NetworkEquipment equipment2 = findEquipmentBySerialNumber(serialNum2);
        // to validate that we have no null input
        if (equipment1 != null && equipment2 != null) {
            // Connect the two equipment
            equipment1.connect(equipment2);
            equipment2.connect(equipment1);
            System.out.println("Equipment connected successfully.");
            fileSaver();
        } else {
            System.out.println("Equipment not found.");
        }
    }

    // Disconnect two equipment from each other
    private static void disconnectEquipment() {
        System.out.print("Enter the serial number of the first equipment: ");
        String serialNum1 = scanner.nextLine();
        System.out.print("Enter the serial number of the second equipment: ");
        String serialNum2 = scanner.nextLine();

        // Find the two equipment objects based on the provided serial numbers
        NetworkEquipment equipment1 = findEquipmentBySerialNumber(serialNum1);
        NetworkEquipment equipment2 = findEquipmentBySerialNumber(serialNum2);
        // Vlaidate that the inputs are not null
        if (equipment1 != null && equipment2 != null) {
            // disconnect the two equipment
            equipment1.disconnect(equipment2);
            equipment2.disconnect(equipment1);
            System.out.println("Equipment disconnected successfully.");
            fileSaver();
        } else {
            System.out.println("Equipment not found.");
        }
    }

    // get the last updated equipment
    private static void getLastUpdatedEquipment() {
        // make sure the updated equipment list is not null or else print that it is empty
        if (!updatedEquipmentList.isEmpty()) {
            // retrieve the last updated equipment from the updatedEquipmentList
            NetworkEquipment lastUpdatedEquipment = updatedEquipmentList.getLast();
            System.out.println("Last updated equipment:");
            System.out.println(lastUpdatedEquipment.toString());
        } else {
            System.out.println("No equipment has been updated yet.");
        }
    }

    private static void getLastNUpdatedEquipment() {
        System.out.print("Enter the number of recently updated equipment to retrieve: ");
        int n = scanner.nextInt();
        scanner.nextLine();

        // make sure the input is not 0 or less
        if (n <= 0) {
            System.out.println("Invalid input. Please enter a positive number.");
            return;
        }

        // Check if there are enough updated equipment to retrieve
        if (updatedEquipmentList.size() < n) {
            System.out.println("There are fewer than " + n + " updated equipment.");
            return;
        }

        System.out.println("Last " + n + " updated equipment:");

        // iterate through the updated equipment list in reverse order and retrieve the last n updated equipment
        for (int i = updatedEquipmentList.size() - 1; i >= updatedEquipmentList.size() - n; i--) {
            NetworkEquipment equipment = updatedEquipmentList.get(i);
            System.out.println(equipment.toString());
        }
    }


    // get all current equipment in a specific location
    private static void getAllCurrentEquipmentInLocation() {

        try{
            System.out.print("Enter the location: ");
            String location = scanner.nextLine();

            System.out.println("Current equipment in " + location + ":");

            // iterate through the equipment list and display all equipment in the specified location
            for (NetworkEquipment equipment : equipmentList) {
                if (equipment.getLocation().equals(location)) {
                    System.out.println(equipment.toString());
                }
            }
        }catch(NullPointerException e){
            System.out.println("An error occured");
        }

    }


    // Get all equipment stored in the library
    private static void getAllEquipment() {
        System.out.println("All equipment:");

        // Display all equipment in the equipmentList
        if(!equipmentList.isEmpty()){
            for (NetworkEquipment equipment : equipmentList) {
                System.out.println(equipment.toString());
            }
        }
        else {
            System.out.println("There is no equipment");
        }
    }

    // Find equipment by its serial number, this method is used for usage in the connect & disconnect methods.
    private static NetworkEquipment findEquipmentBySerialNumber(String serialNumber) {
        // Search the equipmentList for the specified serial number
        for (NetworkEquipment equipment : equipmentList) {
            if (equipment.getSerialNumber().equals(serialNumber)) {
                return equipment;
            }
        }
        return null;
    }

    // Save equipment data to a file
    private static void fileSaver() {
        // try and catch for error handling
        try {
            // Use File Writer library to save any edits to the file
            FileWriter writer = new FileWriter("Equipment.txt");
            for (NetworkEquipment equipment : equipmentList) {
                writer.write("Equipment: " + equipment.toString() + "\n");
            }
            writer.close();
            System.out.println("Result saved to file!");
        } catch (IOException e) {
            System.out.println("An error has occurred while trying to save the data to the file");
            e.printStackTrace();
        }
    }

    // Method to load data from the file to the equipmentList
    // Load equipment data from a file
    private static void loadData(String filename) {
        try {
            FileReader fileReader = new FileReader(filename);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                // Assuming each line in the file represents an equipment
                NetworkEquipment equipment = getEquipment(line);
                if (equipment != null) {
                    equipmentList.add(equipment);
                }
            }
            bufferedReader.close();
            System.out.println("Equipment data loaded successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while loading equipment data from the file: " + e.getMessage());
        }
    }

    // get data from a line of equipment data from the file
    private static NetworkEquipment getEquipment(String line) {
        try {
            // Remove the "Equipment: " from the readed line
            line = line.replace("Equipment: ", "");

            // Split the line by commas to separate the attributes
            String[] attributes = line.split(", ");

            // variables that will store the attribute values
            String name = null;
            String manufacturer = null;
            String modelNumber = null;
            String serialNumber = null;
            String macAddress = null;
            String ipAddress = null;
            String location = null;

            // extract the attribute values from the attribute-value
            for (String attribute : attributes) {
                // split the name of attribute from the value
                String[] parts = attribute.split("=");
                String attributeName = parts[0];
                // remove single quotes around the values
                String attributeValue = parts[1].replace("'", "");

                switch (attributeName) {
                    case "name":
                        name = attributeValue;
                        break;
                    case "manufacturer":
                        manufacturer = attributeValue;
                        break;
                    case "modelNumber":
                        modelNumber = attributeValue;
                        break;
                    case "serialNumber":
                        serialNumber = attributeValue;
                        break;
                    case "macAddress":
                        macAddress = attributeValue;
                        break;
                    case "IpAddress":
                        ipAddress = attributeValue;
                        break;
                    case "Location":
                        location = attributeValue;
                        break;
                }
            }

            // Create a new NetworkEquipment object with the extracted attribute values
            return new NetworkEquipment(name, manufacturer, modelNumber, serialNumber, macAddress, ipAddress, location);
        } catch (Exception e) {
            System.out.println("An error occurred while getting equipment data: " + e.getMessage());
            return null;
        }
    }


}
